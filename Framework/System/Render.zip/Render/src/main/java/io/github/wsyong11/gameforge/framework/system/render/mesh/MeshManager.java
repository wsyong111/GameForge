package io.github.wsyong11.gameforge.framework.system.render.mesh;

import io.github.wsyong11.gameforge.framework.Identifier;
import org.jetbrains.annotations.NotNull;

public interface MeshManager {
	@NotNull
	Mesh load(@NotNull Identifier id);
}
