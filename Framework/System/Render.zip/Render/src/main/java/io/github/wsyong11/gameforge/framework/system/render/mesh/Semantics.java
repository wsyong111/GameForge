package io.github.wsyong11.gameforge.framework.system.render.mesh;

import io.github.wsyong11.gameforge.framework.Identifier;
import lombok.experimental.UtilityClass;

@UtilityClass
public class Semantics {
	public static final Identifier POSITION = Identifier.withDefaultNamespace("position");
	public static final Identifier NORMAL = Identifier.withDefaultNamespace("normal");
	public static final Identifier UV = Identifier.withDefaultNamespace("uv");
}
