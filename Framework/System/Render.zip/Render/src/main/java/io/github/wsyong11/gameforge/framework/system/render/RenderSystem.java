package io.github.wsyong11.gameforge.framework.system.render;

import io.github.wsyong11.gameforge.framework.annotation.ThreadSensitive;
import io.github.wsyong11.gameforge.framework.annotation.UnsafeAPI;
import io.github.wsyong11.gameforge.framework.listener.ListenerList;
import io.github.wsyong11.gameforge.framework.listener.ex.ListenerExceptionCallback;
import io.github.wsyong11.gameforge.framework.system.log.Log;
import io.github.wsyong11.gameforge.framework.system.log.Logger;
import io.github.wsyong11.gameforge.framework.system.log.core.LogLevel;
import io.github.wsyong11.gameforge.framework.system.render.engine.RenderEngine;
import io.github.wsyong11.gameforge.framework.system.render.engine.RenderEngineContext;
import io.github.wsyong11.gameforge.framework.system.render.engine.RenderSystemContext;
import io.github.wsyong11.gameforge.framework.system.render.ex.RenderSystemInitiationException;
import io.github.wsyong11.gameforge.framework.system.render.listener.LogicSizeListener;
import io.github.wsyong11.gameforge.framework.system.render.listener.RenderEngineErrorListener;
import io.github.wsyong11.gameforge.framework.system.render.listener.RendererListener;
import io.github.wsyong11.gameforge.framework.system.render.provider.RenderEngineProvider;
import io.github.wsyong11.gameforge.framework.system.render.provider.WindowManagerProvider;
import io.github.wsyong11.gameforge.framework.system.render.renderer.Renderer;
import io.github.wsyong11.gameforge.framework.system.resource.ResourceProvider;
import io.github.wsyong11.gameforge.framework.system.window.*;
import io.github.wsyong11.gameforge.util.concurrent.TaskHandler;
import io.github.wsyong11.gameforge.util.concurrent.ThreadMark;
import io.github.wsyong11.gameforge.util.concurrent.executor.TaskQueueExecutor;
import io.github.wsyong11.gameforge.util.exception.ExceptionHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector2i;
import org.joml.Vector2ic;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 */
public final class RenderSystem {
	private static final Logger LOGGER = Log.getLogger();

	private static final ThreadLocal<RenderSystem> INSTANCE = new ThreadLocal<>();

	@NotNull
	public static RenderSystem init(
		@NotNull ResourceProvider resourceProvider,
		@NotNull Vector2ic logicSize,
		boolean debug,
		@NotNull RenderEngineProvider engineProvider,
		@NotNull WindowManagerProvider windowManagerProvider
	) throws RenderSystemInitiationException {
		Objects.requireNonNull(resourceProvider, "resourceProvider is null");
		Objects.requireNonNull(logicSize, "logicSize is null");
		Objects.requireNonNull(engineProvider, "engineProvider is null");

		if (INSTANCE.get() != null)
			throw new IllegalThreadStateException("This thread is bound to RenderSystem");

		ThreadMark thread = ThreadMark.get();

		LOGGER.debug("RenderSystem bound to thread {}", thread.getThread());

		RenderSystem renderSystem = new RenderSystem(resourceProvider, engineProvider, windowManagerProvider, logicSize, debug, thread);

		INSTANCE.set(renderSystem);
		return renderSystem;
	}

	public static void loop() {
		RenderSystem instance = getInstance();
		if (instance.isRunning())
			throw new IllegalStateException("Render system for this thread is running");
		instance.loopThis();
	}

	public static void shutdown() {
		RenderSystem instance = getInstanceSafe();
		if (instance == null)
			return;

		LOGGER.debug("Shutdown RenderSystem on thread {}", Thread.currentThread());
		instance.shutdownThis();
		INSTANCE.remove();
	}

	@Nullable
	public static RenderSystem getInstanceSafe() {
		return INSTANCE.get();
	}

	@NotNull
	public static RenderSystem getInstance() {
		RenderSystem instance = getInstanceSafe();
		if (instance == null)
			throw new IllegalThreadStateException("This thread is not bind to RenderSystem");
		return instance;
	}

	// -------------------------------------------------------------------------------------------------------------- //

	private final boolean debug;
	private final Vector2i logicSize;

	private final List<Renderer> renderers;

	private final ListenerList listenerList;

	private final TaskQueueExecutor taskExecutor;
	private final TaskHandler taskHandler;

	private final WindowManager windowManager;
	private final RenderEngine engine;
	private final Window window;

	private final StandardFPSCounter fpsCounter;

	private boolean running;

	private RenderSystem(
		@NotNull ResourceProvider resourceProvider,
		@NotNull RenderEngineProvider provider,
		@NotNull WindowManagerProvider windowManagerProvider,
		@NotNull Vector2ic logicSize,
		boolean debug,
		@NotNull ThreadMark thread
	) throws RenderSystemInitiationException {
		Objects.requireNonNull(resourceProvider, "resourceProvider is null");
		Objects.requireNonNull(provider, "provider is null");
		Objects.requireNonNull(logicSize, "logicSize is null");

		this.logicSize = new Vector2i(logicSize);
		this.debug = debug;

		this.renderers = new ArrayList<>();

		this.listenerList = ListenerList.sync();

		this.taskExecutor = new TaskQueueExecutor();
		this.taskHandler = new TaskHandler(this.taskExecutor, thread);

		this.fpsCounter = new StandardFPSCounter();

		this.running = false;

		try {
			Context context = new Context(thread, this.listenerList, this.taskHandler, debug, resourceProvider);

			this.windowManager = windowManagerProvider.getFactory().get();
			this.engine = provider.getFactory().apply(context);

			this.windowManager.init();
			this.engine.init();

			LOGGER.debug("Building window");
			WindowConfigBuilder windowConfigBuilder = new WindowConfigBuilder()
				.size(new Vector2i(800, 600))
				.position(new Vector2i(100, 100))
				.displayType(WindowDisplayType.WINDOW);
			this.engine.buildWindow(windowConfigBuilder);

			this.window = this.windowManager.createWindow(windowConfigBuilder.build());

			WindowGraphicContext graphicContext = this.window.getGraphicContext();
			graphicContext.bind();
		} catch (Exception e) {
			throw new RenderSystemInitiationException(e);
		}
	}

	// -------------------------------------------------------------------------------------------------------------- //

	public boolean isDebug() {
		return this.debug;
	}

	@NotNull
	public Vector2ic getLogicSize() {
		return this.logicSize;
	}

	public void setLogicSize(@NotNull Vector2ic size) {
		Objects.requireNonNull(size, "size is null");

		if (Objects.equals(this.logicSize, size))
			return;
		this.logicSize.set(size);

		this.listenerList.fire(
			LogicSizeListener.class,
			l -> l.onLogicSizeChanged(this.logicSize),
			ListenerExceptionCallback.log(LOGGER));
	}

	@NotNull
	public Window getWindow() {
		return this.window;
	}

	@NotNull
	@UnsafeAPI
	public WindowManager getWindowManager() {
		return this.windowManager;
	}

	@NotNull
	@UnsafeAPI
	public RenderEngine getEngine() {
		return this.engine;
	}

	// -------------------------------------------------------------------------------------------------------------- //

	@NotNull
	public TaskHandler getTaskHandler() {
		return this.taskHandler;
	}

	@ThreadSensitive
	public void runOnUIThread(@NotNull Runnable action) {
		Objects.requireNonNull(action, "action is null");

		this.taskHandler.run(action);
	}

	public boolean isRunning() {
		return this.running;
	}

	// -------------------------------------------------------------------------------------------------------------- //

	@NotNull
	public FPSCounter getFpsCounter() {
		return this.fpsCounter;
	}

	@ThreadSensitive
	public void registerRenderer(@NotNull Renderer renderer) {
		Objects.requireNonNull(renderer, "renderer is null");

		this.runOnUIThread(() -> {
			if (this.renderers.contains(renderer)) {
				LOGGER.debug("Ignored registered renderer {}", renderer);
				return;
			}

			LOGGER.debug("Registered renderer {}", renderer);

			this.renderers.add(renderer);

			this.listenerList.fire(
				RendererListener.class,
				l -> l.onRendererRegister(renderer),
				ListenerExceptionCallback.log(LOGGER)
			);
		});
	}

	@ThreadSensitive
	public void unregisterRenderer(@NotNull Renderer renderer) {
		Objects.requireNonNull(renderer, "renderer is null");

		this.runOnUIThread(() -> {
			if (!this.renderers.remove(renderer))
				return;

			LOGGER.debug("Unregistered renderer {}", renderer);

			this.listenerList.fire(
				RendererListener.class,
				l -> l.onRendererUnregister(renderer),
				ListenerExceptionCallback.log(LOGGER)
			);
		});
	}

	// -------------------------------------------------------------------------------------------------------------- //

	private void executeTask() {
		this.taskExecutor.run(exception ->
			LOGGER.error("An exception occurred during running a task", exception));
	}

	private void loopThis() {
		if (this.running)
			return;
		this.running = true;

		WindowGraphicContext windowGraphicContext = this.window.getGraphicContext();

		this.window.setVisible(true);

		while (this.running) {
			this.executeTask();

			// FIX: Causes state abnormality when modifying state in a task
			if (!this.running)
				break;

			this.engine.preRender();

			this.fpsCounter.start();

			this.engine.render(List.of());

			windowGraphicContext.swap();
			this.windowManager.update();

			this.fpsCounter.end();
		}
	}

	// -------------------------------------------------------------------------------------------------------------- //

	private void shutdownThis() {
		this.running = false;

		this.listenerList.clear();

		if (!this.taskExecutor.isEmpty())
			LOGGER.warn("Task queue is not empty");

		this.taskExecutor.clear();

		this.window.getGraphicContext().unbind();

		ExceptionHandler
			.create()
			.run(this.engine::close)
			.pickOnce(e -> LOGGER.warn("An exception occurred while closing the render engine", e))
			.run(this.window::close)
			.pickOnce(e -> LOGGER.warn("Cannot close the window", e))
			.run(this.windowManager::close)
			.pickOnce(e -> LOGGER.warn("An exception occurred while closing the window manager", e));
	}

	public void reloadShader() {

	}

	// -------------------------------------------------------------------------------------------------------------- //

	private static class Context implements RenderSystemContext, RenderEngineContext {
		private final ThreadMark thread;
		private final ListenerList listenerList;
		private final TaskHandler taskHandler;
		private final boolean debug;
		private final ResourceProvider resourceProvider;

		public Context(
			@NotNull ThreadMark thread,
			@NotNull ListenerList listenerList,
			@NotNull TaskHandler taskHandler,
			boolean debug,
			@NotNull ResourceProvider resourceProvider
		) {
			Objects.requireNonNull(listenerList, "listenerList is null");
			Objects.requireNonNull(taskHandler, "taskHandler is null");
			Objects.requireNonNull(resourceProvider, "resourceProvider is null");

			this.thread = thread;
			this.listenerList = listenerList;
			this.taskHandler = taskHandler;
			this.debug = debug;
			this.resourceProvider = resourceProvider;
		}

		@Override
		public boolean isDebug() {
			return this.debug;
		}

		@Override
		public void error(@NotNull LogLevel level, @NotNull String message, int code) {
			Objects.requireNonNull(level, "level is null");
			Objects.requireNonNull(message, "message is null");

			this.listenerList.fire(
				RenderEngineErrorListener.class,
				l -> l.onRenderEngineError(level, message, code),
				ListenerExceptionCallback.log(LOGGER));
		}

		@Override
		public void registerLogicSizeListener(@NotNull LogicSizeListener listener) {
			Objects.requireNonNull(listener, "listener is null");
			this.listenerList.add(LogicSizeListener.class, listener);
		}

		@Override
		public void unregisterLogicSizeListener(@NotNull LogicSizeListener listener) {
			Objects.requireNonNull(listener, "listener is null");
			this.listenerList.remove(LogicSizeListener.class, listener);
		}

		@Override
		public void registerRendererListener(@NotNull RendererListener listener) {
			Objects.requireNonNull(listener, "listener is null");
			this.listenerList.add(RendererListener.class, listener);
		}

		@Override
		public void unregisterRendererListener(@NotNull RendererListener listener) {
			Objects.requireNonNull(listener, "listener is null");
			this.listenerList.remove(RendererListener.class, listener);
		}

		@NotNull
		@Override
		public TaskHandler getTaskHandler() {
			return this.taskHandler;
		}

		@Override
		public boolean isRenderThread() {
			return this.thread.check();
		}

		@NotNull
		@Override
		public ResourceProvider getResourceProvider() {
			return this.resourceProvider;
		}
	}

	private static class StandardFPSCounter implements FPSCounter {
		private long frameTimeNs;
		private float fps;

		private long startTimeNs;

		public StandardFPSCounter() {
			this.frameTimeNs = 0L;
			this.fps = 0.0F;

			this.startTimeNs = 0L;
		}

		public void start() {
			this.startTimeNs = System.nanoTime();
		}

		public void end() {
			long time = System.nanoTime();

			this.frameTimeNs = time - this.startTimeNs;
			this.fps = 1.0E9F / this.frameTimeNs;
		}

		@Override
		public long getFrameTimeNs() {
			return this.frameTimeNs;
		}

		@Override
		public float getFPS() {
			return this.fps;
		}
	}
}
