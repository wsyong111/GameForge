package io.github.wsyong11.gameforge.framework.system.render.mesh;

import io.github.wsyong11.gameforge.framework.Identifier;
import io.github.wsyong11.gameforge.framework.system.render.mesh.vertex.VertexAttribute;
import io.github.wsyong11.gameforge.framework.system.render.mesh.vertex.VertexDataType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.UnmodifiableView;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.util.Objects;
import java.util.Set;

public class SimpleDirectMesh implements Mesh {
	private final Identifier id;
	private final int vertexCount;

	public SimpleDirectMesh(@NotNull Identifier id, @NotNull IntBuffer indexBuffer, int vertexCount) {
		Objects.requireNonNull(id, "id is null");

		this.id = id;
		this.vertexCount = vertexCount;
	}

	@NotNull
	@Override
	public Identifier getId() {
		return this.id;
	}

	@Nullable
	@Override
	public VertexAttribute getAttribute(@NotNull String name) {
		return null;
	}

	@NotNull
	@UnmodifiableView
	@Override
	public Set<String> getAttributes() {
		return Set.of();
	}

	@NotNull
	@UnmodifiableView
	@Override
	public IntBuffer getIndexBuffer() {
		return null;
	}

	@Override
	public int getIndexCount() {
		return 0;
	}

	@Override
	public int getVertexCount() {
		return this.vertexCount;
	}

	@Override
	public void close() {

	}

	public static class Attribute implements VertexAttribute {
		@NotNull
		@Override
		public String getName() {
			return "";
		}

		@NotNull
		@Override
		public VertexDataType getType() {
			return null;
		}

		@NotNull
		@UnmodifiableView
		@Override
		public ByteBuffer getBuffer() {
			return null;
		}
	}
}
