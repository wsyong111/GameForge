package io.github.wsyong11.gameforge.framework.system.render.mesh.vertex;

import io.github.wsyong11.gameforge.framework.Identifier;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import org.apache.commons.text.StringEscapeUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.UnmodifiableView;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class VertexLayout {
	@NotNull
	public static Builder builder() {
		return new Builder();
	}

	private final List<Item> items;
	private final Map<Identifier, Item> itemMap;
	private final Map<String, Item> itemKeyMap;

	private final int stride;
	private final Object2IntMap<Identifier> offsetMap;

	protected VertexLayout(@NotNull List<Item> items) {
		Objects.requireNonNull(items, "items is null");

		this.items = List.copyOf(items);

		Map<Identifier, Item> itemMap = new HashMap<>(this.items.size());
		HashMap<String, Item> itemKeyMap = new HashMap<>(this.items.size());
		for (Item item : items) {
			Identifier semantic = item.getSemantic();
			if (itemMap.containsKey(semantic))
				throw new IllegalArgumentException("Duplicate semantic found in items: " + semantic);

			itemMap.put(semantic, item);
			itemKeyMap.put(item.getKey(), item);
		}

		this.itemMap = Collections.unmodifiableMap(itemMap);
		this.itemKeyMap = Collections.unmodifiableMap(itemKeyMap);

		this.stride = this.items
			.stream()
			.map(Item::getDataType)
			.mapToInt(VertexDataType::getByteSize)
			.sum();

		Object2IntMap<Identifier> offsetMap = new Object2IntOpenHashMap<>(this.items.size());

		int offset = 0;
		for (Item item : this.items) {
			offsetMap.put(item.getSemantic(), offset);
			offset += item.getDataType().getByteSize();
		}

		this.offsetMap = offsetMap;
	}

	@NotNull
	public Item getBySemantic(@NotNull Identifier semantic) {
		Objects.requireNonNull(semantic, "semantic is null");
		return this.itemMap.get(semantic);
	}

	public boolean hasSemantic(@NotNull Identifier semantic) {
		Objects.requireNonNull(semantic, "semantic is null");
		return this.itemMap.containsKey(semantic);
	}

	@NotNull
	public Item getByKey(@NotNull String key) {
		Objects.requireNonNull(key, "key is null");
		return this.itemKeyMap.get(key);
	}

	public boolean hasKey(@NotNull String key) {
		Objects.requireNonNull(key, "key is null");
		return this.itemKeyMap.containsKey(key);
	}

	public int getStride() {
		return this.stride;
	}

	public int getOffset(@NotNull Identifier semantic) {
		Objects.requireNonNull(semantic, "semantic is null");

		if (!this.offsetMap.containsKey(semantic))
			throw new IllegalArgumentException("Semantic is not in layout");

		return this.offsetMap.getInt(semantic);
	}

	@NotNull
	@UnmodifiableView
	public List<Item> getItems() {
		return this.items;
	}

	public static class Item {
		private final String key;
		private final VertexDataType dataType;
		private final Identifier semantic;

		public Item(@NotNull String key, @NotNull VertexDataType dataType, @NotNull Identifier semantic) {
			Objects.requireNonNull(key, "key is null");
			Objects.requireNonNull(dataType, "dataType is null");
			Objects.requireNonNull(semantic, "semantic is null");

			this.key = key;
			this.dataType = dataType;
			this.semantic = semantic;
		}

		@NotNull
		public String getKey() {
			return this.key;
		}

		@NotNull
		public VertexDataType getDataType() {
			return this.dataType;
		}

		@NotNull
		public Identifier getSemantic() {
			return this.semantic;
		}

		@NotNull
		public ItemBuilder asBuilder() {
			return new ItemBuilder(this);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || getClass() != o.getClass()) return false;
			Item item = (Item) o;
			return Objects.equals(this.key, item.key)
				&& Objects.equals(this.dataType, item.dataType)
				&& Objects.equals(this.semantic, item.semantic);
		}

		@Override
		public int hashCode() {
			return Objects.hash(this.key, this.dataType, this.semantic);
		}

		@Override
		public String toString() {
			return "[\"" + StringEscapeUtils.escapeJava(this.key) + "\" " + this.dataType + " " + this.dataType.getByteSize() + "bytes]";
		}
	}

	@Override
	public String toString() {
		return "VertexLayout[" + this.items
			.stream()
			.map(Item::toString)
			.collect(Collectors.joining()) + "]";
	}

	public static class Builder {
		private final Map<Identifier, Item> items;

		public Builder() {
			this.items = new LinkedHashMap<>();
		}

		@NotNull
		public Builder add(@NotNull ItemBuilder builder) {
			Objects.requireNonNull(builder, "builder is null");
			return this.add(builder.build());
		}

		@NotNull
		public Builder add(@NotNull Consumer<ItemBuilder> action) {
			Objects.requireNonNull(action, "action is null");
			ItemBuilder builder = new ItemBuilder();
			action.accept(builder);
			return this.add(builder.build());
		}

		@NotNull
		public Builder add(@NotNull Item item) {
			Objects.requireNonNull(item, "item is null");

			Identifier semantic = item.getSemantic();
			if (this.items.containsKey(semantic))
				throw new IllegalStateException("Semantic " + semantic + " existed");

			this.items.put(semantic, item);
			return this;
		}

		@NotNull
		public Builder add(@NotNull String semantic, @NotNull String meshKey, @NotNull VertexDataType dataType) {
			Objects.requireNonNull(semantic, "semantic is null");
			Objects.requireNonNull(meshKey, "meshKey is null");
			Objects.requireNonNull(dataType, "dataType is null");
			return this.add(Identifier.parseTolerance(semantic), meshKey, dataType);
		}

		@NotNull
		public Builder add(@NotNull Identifier semantic, @NotNull String meshKey, @NotNull VertexDataType dataType) {
			Objects.requireNonNull(semantic, "semantic is null");
			Objects.requireNonNull(meshKey, "meshKey is null");
			Objects.requireNonNull(dataType, "dataType is null");

			if (this.items.containsKey(semantic))
				throw new IllegalStateException("Semantic " + semantic + " existed");

			this.items.put(semantic, new Item(meshKey, dataType, semantic));
			return this;
		}

		@NotNull
		public Builder replace(@NotNull String semantic, @NotNull String meshKey, @NotNull VertexDataType dataType) {
			Objects.requireNonNull(semantic, "semantic is null");
			Objects.requireNonNull(meshKey, "meshKey is null");
			Objects.requireNonNull(dataType, "dataType is null");
			return this.replace(Identifier.parseTolerance(semantic), meshKey, dataType);
		}

		@NotNull
		public Builder replace(@NotNull ItemBuilder builder) {
			Objects.requireNonNull(builder, "builder is null");
			return this.replace(builder.build());
		}

		@NotNull
		public Builder replace(@NotNull Consumer<ItemBuilder> action) {
			Objects.requireNonNull(action, "action is null");
			ItemBuilder builder = new ItemBuilder();
			action.accept(builder);
			return this.replace(builder.build());
		}

		@NotNull
		public Builder replace(@NotNull Item item) {
			Objects.requireNonNull(item, "item is null");
			this.items.put(item.getSemantic(), item);
			return this;
		}

		@NotNull
		public Builder replace(@NotNull Identifier semantic, @NotNull String meshKey, @NotNull VertexDataType dataType) {
			Objects.requireNonNull(semantic, "semantic is null");
			Objects.requireNonNull(meshKey, "meshKey is null");
			Objects.requireNonNull(dataType, "dataType is null");
			this.items.put(semantic, new Item(meshKey, dataType, semantic));
			return this;
		}

		@NotNull
		public Builder remove(@NotNull Identifier semantic) {
			Objects.requireNonNull(semantic, "semantic is null");
			this.items.remove(semantic);
			return this;
		}

		@NotNull
		public VertexLayout build() {
			List<Item> items = List.copyOf(this.items.values());
			return new VertexLayout(items);
		}
	}

	public static class ItemBuilder {
		private Identifier semantic;
		private String key;
		private VertexDataType dataType;

		public ItemBuilder() {
			this.semantic = null;
			this.key = null;
			this.dataType = null;
		}

		public ItemBuilder(@NotNull Item item) {
			Objects.requireNonNull(item, "item is null");

			this.semantic = item.getSemantic();
			this.key = item.getKey();
			this.dataType = item.getDataType();
		}

		@NotNull
		public ItemBuilder semantic(@NotNull Identifier semantic) {
			Objects.requireNonNull(semantic, "semantic is null");
			this.semantic = semantic;
			return this;
		}

		@NotNull
		public ItemBuilder key(@NotNull String key) {
			Objects.requireNonNull(key, "key is null");
			this.key = key;
			return this;
		}

		@NotNull
		public ItemBuilder dataType(@NotNull VertexDataType dataType) {
			Objects.requireNonNull(dataType, "dataType is null");
			this.dataType = dataType;
			return this;
		}

		@NotNull
		public Item build() {
			Objects.requireNonNull(this.key,"Require key");
			Objects.requireNonNull(this.dataType,"Require data type");
			Objects.requireNonNull(this.semantic,"Require semantic");
			return new Item(this.key, this.dataType, this.semantic);
		}
	}
}
